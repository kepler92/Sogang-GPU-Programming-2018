#pragma once


void jacobi_method(int N, double *B, double *X, int NELT, int *IA, int *JA, double *A, int iter);
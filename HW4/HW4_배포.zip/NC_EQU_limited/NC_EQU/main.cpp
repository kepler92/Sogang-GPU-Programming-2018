#include <stdlib.h>

#define Iteration_Number 100000

extern "C" {
    int dsgs_(int *n, double *b, double *x, int *nelt, int *ia, int *ja, double *a, int *isym, int *itol, double *tol, int *itmax,
        int *iter, double *err, int *ierr, int *iunit, double *rwork, int *lenw, int *iwork, int *leniw);
}

int main() {
    int N;
    double* B;
    double* X;
    int NELT;
    int* IA;
    int* JA;
    double* A;
    int ISYM;
    int ITOL;
    double TOL;
    int ITMAX;
    int ITER;
    double ERR;
    int IERR;
    int IUNIT;
    double* RWORK;
    int LENW;
    int* IWORK;
    int LENIW;

    N;
    B = (double *)malloc(N * sizeof(double));
    X = (double *)malloc(N * sizeof(double));
    NELT;
    IA = (int *)malloc(NELT * sizeof(int));
    JA = (int *)malloc(NELT * sizeof(int));
    A = (double *)malloc(NELT * sizeof(double));
    ISYM = 1;
    ITOL = 11;
    TOL = 0.00000001;
    ITMAX = Iteration_Number;
    IUNIT = 0;
    RWORK = (double *)malloc((NELT + 3 * N) * sizeof(double));
    LENW = NELT + 3 * N + 1;
    IWORK = (int *)malloc((NELT + 2 * N + 11) * sizeof(int));
    LENIW = NELT + 2 * N + 11;

    dsgs_(&N, B, X, &NELT, IA, JA, A, &ISYM, &ITOL, &TOL, &ITMAX, &ITER, &ERR, &IERR, &IUNIT, RWORK, &LENW, IWORK, &LENIW);

    free(B);
    free(X);
    free(IA);
    free(JA);
    free(A);
    free(RWORK);
    free(IWORK);

    return 0;
}
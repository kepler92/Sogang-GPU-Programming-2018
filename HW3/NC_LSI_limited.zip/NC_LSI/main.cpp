#include <stdio.h>
#include <stdlib.h>

#define min(X,Y) ((X) < (Y) ? (X) : (Y))  
#define max(X,Y) ((X) > (Y) ? (X) : (Y)) 

extern "C" {
    void dsvdc_(double* x, int* ldx, int* n, int* p, double* s, double* e, double* u, int* ldu, double* v, int* ldv, double* work, int* job, int* info);
}

int main() {
    int K;
    int row;        //# of keyword
    int column;     //# of docu

    double* A;
    double* U;
    double* D;
    double* V;

    A = new double[row*column];

    int LDX = row;
    int N = row;
    int P = column;
    int LDU = row;
    int LDV = column;
    U = (double*)malloc(row * min(row, column) * sizeof(double));
    D = (double*)malloc(min(row + 1, column) * sizeof(double));
    V = (double*)malloc(column * column * sizeof(double));
    double* E = (double*)malloc(row * sizeof(double));
    double* WORK = (double*)malloc(row * sizeof(double));
    int JOB = 21;
    int INFO;

    dsvdc_(A, &LDX, &N, &P, D, E, U, &LDU, V, &LDV, WORK, &JOB, &INFO);

    return 0;
}
